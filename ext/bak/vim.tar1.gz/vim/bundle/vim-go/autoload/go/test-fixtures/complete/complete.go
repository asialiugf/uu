package complete

type T struct {
	V string
}

func Example(s string) {
	Example("")
}
